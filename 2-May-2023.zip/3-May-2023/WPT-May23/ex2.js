var x = 20

x=34.5
x=true
x="hello"
x='hello'
x=` this is a string that spans
multiple line so it is a
multi line string use
backtick `

var w=435
x= `the value w is ${w} and it is greater than 100`

x=[12,22,33,44,55]
console.log("x=",x," type of x is ",typeof(x))

var y
console.log("y=",y,"type of y is ",typeof(y))








