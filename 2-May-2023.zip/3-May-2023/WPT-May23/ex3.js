let p
console.log(p)

const x=100
//x="hello"  //this is not allowed to change const !!
console.log(x)

