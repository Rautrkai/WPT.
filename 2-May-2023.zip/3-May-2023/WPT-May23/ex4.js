let num=400 

if(num%2 == 0)
{
     console.log(num," is even ")
}
else
{
    console.log(num," is odd")
}