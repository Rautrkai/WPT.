let str="hello"
let str2 ="world"
console.log (str.concat(str2))
console.log(str.concat(str2).substring(3,4))
console.log(str.charAt(1).toUpperCase())
console.log(str.substring(2,3))

