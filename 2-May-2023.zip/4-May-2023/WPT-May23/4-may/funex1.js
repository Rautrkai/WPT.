function sayHello(nm)
{
    console.log("hello",nm)
}


sayHello("prachi")
sayHello()
sayHello("prachi","priti","prakash")