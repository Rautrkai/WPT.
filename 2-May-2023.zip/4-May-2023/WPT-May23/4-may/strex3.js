let str = "POWERED"

let s = str.slice(1,-1)
console.log(s)