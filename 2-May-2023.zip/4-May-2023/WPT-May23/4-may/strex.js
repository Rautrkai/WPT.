// let str="confidence"  //primitive declaration using literals 

// let st2 = new String("I have confidence in me");  //object declaration using new 

// let st3 = new String("confidence")
// //compare the strings 

// console.log("type of str",typeof(str))
// console.log("type of st3",typeof(st3))
// //if(str === st3.valueOf())
// if(str == st3 )
//    console.log(str, " is same as ", st3)
// else
//     console.log(str, " is not same as ", st3)


//let s1 = "brave"
//let s2 = "brave"

// let s1 = new String("brave");
// let s2 = new String("brave");

// //if(s1 == s2) //as s1 and s2 are objects their addresses are compared 
// if(s1 === s2) //as s1 and s2 are objects their addresses are compared 
//     console.log("same")
// else 
//    console.log("different")


let s1= new String("1")
let x = 1

if( s1 === x)
   console.log("same")
else
   console.log("different")







